//
//  TableViewCell.swift
//  new
//
//  Created by kumar on 24/09/24.
//

import UIKit

class HeaderCell: UITableViewCell {
    @IBOutlet weak var lbl: UILabel!
    
}


class TableViewCell: UITableViewCell {
    @IBOutlet weak var collvw: UICollectionView!
    @IBOutlet weak var collvwHight: NSLayoutConstraint!
    var listArray = [moreSlotsBase.TimeSlot]()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collvw.delegate = self
        collvw.dataSource = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//--------------------------------------------

//MARK: Collection View Methods

extension TableViewCell: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listArray.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell
        cell?.lbl.text = listArray[indexPath.item].end_time ?? ""
        return cell ?? UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/3-10, height: 40)
    }
}

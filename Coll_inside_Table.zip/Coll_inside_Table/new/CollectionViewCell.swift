//
//  CollectionViewCell.swift
//  new
//
//  Created by kumar on 24/09/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lbl: UILabel!
}


//
//  ViewController.swift
//  new
//
//  Created by kumar on 24/09/24.
//

import UIKit
import Alamofire
let urlCh = "https://chowtrux.com/api/anonymous-user/food_truck_list_by_slot_at_on_location"
    let parmsCh = ["dates": "2024-09-24,2024-09-25", "longitude": -111.8864963, "food_truck_id": "910", "all": "0", "timezone": "Asia/Kolkata", "open_now": "0", "latitude": 40.3750067, "cuisines": "0"] as [String : Any]

var modalData = Optional( new.moreSlotsBase(status: Optional(true), code: Optional(200), slotData: Optional([ new.moreSlotsBase.moreSlotsData(date: Optional("2024-09-11"), time: Optional([ new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 03:30:00"), end_time: Optional("2024-09-11 08:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00"))])),  new.moreSlotsBase.moreSlotsData(date: Optional("2024-09-12"), time: Optional([ new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-12 03:30:00"), end_time: Optional("2024-09-12 08:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-12 22:30:00"), end_time: Optional("2024-09-13 01:30:00"))])),  new.moreSlotsBase.moreSlotsData(date: Optional("2024-09-11"), time: Optional([ new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 03:30:00"), end_time: Optional("2024-09-11 08:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00")),  new.moreSlotsBase.TimeSlot(start_time: Optional("2024-09-11 22:30:00"), end_time: Optional("2024-09-12 01:30:00"))]))])))

struct moreSlotsBase : Codable {
    let status : Bool?
    let code : Int?
    let slotData : [moreSlotsData]?
    
    enum CodingKeys: String, CodingKey {
        
        case status = "status"
        case code = "code"
        case slotData = "data"
    }
    

    
    
    
    
    struct moreSlotsData : Codable {
        let date : String?
        let time : [TimeSlot]?
        
        enum CodingKeys: String, CodingKey {
            
            case date = "date"
            case time = "time"
        }
        

    }
    
    
    
    struct TimeSlot : Codable {
        let start_time : String?
        let end_time : String?
        
        enum CodingKeys: String, CodingKey {
            
            case start_time = "start_time"
            case end_time = "end_time"
        }
        

        
    }
    
}


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    //var modalData: moreSlotsBase?
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return modalData?.slotData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tblvw.dequeueReusableCell(withIdentifier: "HeaderCell") as! HeaderCell
        cell.lbl.text = modalData?.slotData?[section].date ?? ""
        return cell.contentView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblvw.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.frame = tblvw.bounds
        cell.layoutIfNeeded()
        
        cell.listArray = modalData?.slotData?[indexPath.section].time ?? []
        cell.collvw.reloadData()
        cell.collvwHight.constant = cell.collvw.collectionViewLayout.collectionViewContentSize.height
        return cell
    }
    

    @IBOutlet weak var tblvw: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tblvw.delegate = self
        tblvw.dataSource = self
        
    }


}

